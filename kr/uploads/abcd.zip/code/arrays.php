<html>
	<head>
		<title> Programski Praktikum </title>
	</head>
	<body>
		<p>
			<?php
				$pole = array("prv","vtor","tret");
				$pole1 = array("element1"=>"prv",
							   "elemenet2"=>"vtor",
							   "element3"=>"tret");
				$brojElementi = count($pole);
				print_r($pole);
				echo("<br/>");
				print_r($pole1);
				echo("<br/>");
				array_push($pole, "cetvrt");
				print_r($pole);
				array_pop($pole);
				array_pop($pole);
				echo("<br/>");
				print_r($pole);
				$pole[2]="3";
				$pole[0]="1";
				echo("<br/>");
				print_r($pole);
			?>
		</p>
	</body>
</html>
