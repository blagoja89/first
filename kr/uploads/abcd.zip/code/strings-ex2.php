<html>
	<head>
		<title>Programski Praktikum</title>
	</head>
	<body>
		<p>
				<?php
				$promenliva = "Programski Praktikum - 2011";
				$promenliva1 = str_replace("2011","2013 <strong>godina</strong>",$promenliva);
				$promenliva2 = strip_tags($promenliva1);
				echo($promenliva);
				echo("<br/>");
				echo($promenliva1);
				echo("<br/>");
				echo($promenliva2);
				echo("<br/>");
				?>
		</p>
	</body>
</html>
