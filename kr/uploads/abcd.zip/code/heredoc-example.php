<?php
$var = "Double quoted string";
$str = <<<LABEL
This is a heredoc string.
It can span multiple lines 
and behaves like $var
LABEL;
echo($str);
$here_doc = <<<"TXT"
This is a heredoc also
TXT;
?>
