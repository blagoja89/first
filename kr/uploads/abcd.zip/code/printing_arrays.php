<pre>
<?php
$a = array ('a' => 'apple', 'b' => 'banana', 'c' => array ('x', 'y', 'z'));

echo "Using print_r:\n";
print_r ($a);

print("\nUsing var_dump:\n");

var_dump($a);
?>
</pre>
