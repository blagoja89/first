﻿<html>
	<head>
		<title>Електронска пријава</title>
    </head>
	<body>
<?php
function check_input($data, $problem='')
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    if ($problem && strlen($data) == 0)
    {
        show_error($problem);
    }
    return $data;
}
function show_error($myError)
{
?>
    <b>Please correct the following error:</b><br />
    <?php echo $myError; ?>
<?php
exit();
}
?>
<?php
$ime = check_input($_POST['ime'], "Името е задолжителен податок!");
$prezime = check_input($_POST['prezime'], "Презимето е задолжителен податок!");
$data_raganje = check_input($_POST['data_raganje'], "Датата на раѓање е задолжителен податок!");
$email = check_input($_POST['email'], "Емаилот е задолжителен податок!");
$indeks = check_input($_POST['indeks'], "Индексот е задолжителен податок!");
$tel = check_input($_POST['tel'], "Телефонскиот број е задолжителен податок!");
$pol = $_POST['pol'];
$fakultet = $_POST['fakultet'];
$brPredmeti = check_input($_POST['brPredmeti'], "Бројот на предмети е задолжителен податок!");
$ZbirOcenka = check_input($_POST['ZbirOcenka'], "Збирот на оценките од предметите е задолжителен податок!");
$prosek = $ZbirOcenka / $brPredmeti;

$data_raganje_ = explode(".", $data_raganje);
$emails = explode(";", $email);
foreach($emails as $em){
	if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$em))
	{
		show_error("Емаилот не е валиден!");
	}
}
	if(!checkdate($data_raganje_[1],$data_raganje_[0],$data_raganje_[2]))
	{
		show_error("Датата на раѓање не е валидна!");
	}
	$tells = explode(";", $tel);

?>
	<table>
		<tr><td>Име:</td><td><?php echo($ime); ?></td></tr>
		<tr><td>Презиме:</td><td><?php echo($prezime); ?></td></tr>
		<tr><td>Дата на раѓање:</td><td><?php echo($data_raganje); ?></td></tr>
		<tr><td valign="top">Е-маил:</td><td>
		<?php
			for ($i = 0; $i < count($emails); $i++) 
			{
				echo($emails[$i]."<br />"); 
			}
		?>
		</td></tr>
		<tr><td>Индекс:</td><td><?php echo($indeks); ?></td></tr>
		<tr><td valign="top">Телефонски број:</td><td>
		<?php
			for ($i = 0; $i < count($tells); $i++) 
			{
				echo($tells[$i]."<br />"); 
			}
		?>
		</td></tr>
		<tr><td>Пол:</td><td><?php echo($pol); ?></td></tr>
		<tr><td>Факултет:</td><td> <?php echo($fakultet); ?></td></tr>
		<tr><td>Број на положени предмети:</td><td><?php echo($brPredmeti); ?></td></tr>
		<tr><td>Збир на оценки:</td><td><?php echo($ZbirOcenka); ?></td></tr>
		<tr><td>Просечна оценка:</td><td><?php echo($prosek); ?></td></tr>
	</table>
	</body>
</html>
<?php  ?>