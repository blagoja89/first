<html>
	<head>
		<title>Programski Praktikum</title>
	</head>
	<body>
		<p>
			<?php
				$promenliva = "Programski praktikum";
				$dolzina = strlen($promenliva);
				$pozicija = strpos($promenliva,"praktikum");
				echo($promenliva);
				echo("<br />");
				echo("Dolzinata na stringot e:".$dolzina);
				echo("<br />");
				echo("Pozicijata na zborot praktikum vo stringot e:".$pozicija);
			?>
		</p>
	</body>
</html>
