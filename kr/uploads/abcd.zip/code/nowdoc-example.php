<?php
$variables = 'Single quoted string';
$str = <<<'LABEL'
This is a nowdoc string.
It can span multiple lines 
and does not expand $variables
LABEL;
echo($str);
?>
