<?php
$var = 3;

echo "Result: " . $var + 3;

echo "<br />";

$x = 1;
echo 'foo: ' . $x+1 . ' bar';
?>
